# ResumerBuilder
Online resume builder application for an organisation

Ritam is a very good guy /sarcasm
